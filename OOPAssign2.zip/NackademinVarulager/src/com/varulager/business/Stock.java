package com.varulager.business;

public interface Stock {
	
	public String getStockLocation();
	public void setStockLocation(String stockLocation);
	
}
