package com.nackademin.objpr.ui1;

import java.util.Scanner;

public class CalcInteraction {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		SimpleCalc calc = new SimpleCalc();
		int tal1;
		int tal2;
		
		System.out.println("Hej och v�lkommen" +
				"till min simpla minir�knare." +
				"Var v�nlig och v�lj ett av " +
				"f�ljande alternativ: ");
		while(true){
			int operator = 0;
			System.out.println("1 = Starta minr�knaren, 2 = Resultat, 0 = Avsluta programmet");
			int choice = input.nextInt();
			if(choice < 0 || choice > 2){ System.out.println("Du valde fel. V�lj igen."); continue;}
			else if(choice == 0){ break; }
			else if(choice == 1) {
				while(operator < 1 || operator > 4){
					System.out.println("V�lj en av dessa operatorer som du vill till�mpa.");
					System.out.println("1 = +, 2 = -, 3 = *, 4 = /");
					operator = input.nextInt();
				}
				System.out.println("Mata in tal ett.");
				tal1 = input.nextInt();
				System.out.println("Mata in tal tv�");
				tal2 = input.nextInt();
				System.out.println(Math.round(calc.calculate(operator, tal1, tal2)));
			} else {
				double[] results = calc.getResult();
				System.out.print("De tre senaste resultaten �r: ");
				for(double result : results){
					System.out.print(Math.round(result) + ", ");
				}
				System.out.println();
			}
		}
		System.out.println("Programmet har avslutats.");
		input.close();
	}

}
