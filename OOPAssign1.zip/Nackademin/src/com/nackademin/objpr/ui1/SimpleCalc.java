package com.nackademin.objpr.ui1;

public class SimpleCalc {
	private double results[] = new double[3];
	
	public double calculate(int operator, double tal1, double tal2){
		double temp = results[1];
		results[1] = results[0];
		results[2] = temp;
		switch(operator){
		case 1:
			results[0] = tal1 + tal2;
			break;
		case 2:
			results[0] = tal1 - tal2;
			break;
		case 3:
			results[0] = tal1 * tal2;
			break;
		case 4:
			results[0] = tal1 / tal2;
			break;
		}
		return results[0];
	}
	public double[] getResult(){
		return this.results;
	}
	

}
